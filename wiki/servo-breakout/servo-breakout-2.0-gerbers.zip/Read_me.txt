 Version 2.0

 Changes since V1.6:

 JST SH socket now faces inward in order to simplify wiring

 XT30 connector moved to the bottom of the PCB (also makes wiring easier)

 Solder pads for TPS76701QD changed from rectangular to oval

 The anchor pads for the JST SH socket now stick out from under the front further in
 order to make hand soldering easier (use liquid flux and flow solder onto the pad)


 Components required:

 U1  Texas Instruments TPS76701QD (lettering is upside down when looking at PCB with pin header at bottom)

 P1  JST SH1.0 10 position (anchor pads are longer than normal to make hand soldering easy, touch iron to protruding part to flow solder under he connector. liquid flux helps with this)

 CN1  XT30PW-M (optional can solder power lead directly. Connector is only to be used for attaching a pigtail or switch not as means of connecting battery directly)

 D1 LSM115JE3/TR13 (cathode bar toward top of PCB.)

 R1  96k 1/8W (Xicon 270-96K-RC or similar 1/8W 1% or better metal film miniature resistor approx. 3.5mm length)

 R2  30.1K 1/8W (Xicon 270-30.1K-RC or similar 1/8W 1% or better metal film miniature resistor approx. 3.5mm length)

 C1  100nF ceramic capacitor 2.5mm lead spacing (Vishay K104K10X7RF5TL2 or similar X7R or X5R 20% or better radial capacitor)

 C2  10nF ceramic capacitor 2.5mm lead spacing (Vishay K103K10X7RF53L2 or similar X7R or X5R 20% or better radial capacitor)

 C3 22uF C1210 ceramic capacitor (Samsung CL32B226MOJNNNE Samwha CS3225X7R226K160NRL or similar X7R or X5R 20% or better)

 C4 47uF C1210 ceramic capacitor (Samsung CL32B476MPJNNNE Samwha CS3225X7R476K100NRL or similar X7R or X5R 20% or better)

 If 10% or better is used close similar capacitor values may be substituted. C3 MUST be 10uF or greater (less than approx. 30uF) when considering tolerance.

 X5R caps will work fine for this application.


 
 General information:

 5V on JST is connected to 5V rail on flight controller NOT to Vbat

 Gnd is connected to ground

 If 5V light does not come on try a different 5V pad. (Blitz I7 Mini 5V light will not work if 5V on DJI header is used, however FC still works. Light works with all other 5V pads on FC)

 FC may or may not be able to see voltage from 5V rail (Mamba Mini did, Blitz I7 Mini did not)

 "no JLPCB" version has the locating text for serial numbers and .txt file inside gerber zip removed. To remove serial locating text on mounting plate and cover plate gerbers delete the lower silkscreen layer.

 If the power lead is direct soldered to the pads then the plain mounting plate with no cutout for an XT30 should be used.

 Exact voltage from 5V out from regulator will vary slightly due to resistor tolerances 4.94v-4.99v is typical.

 Resistor bridge is connected after or-ing diode so there is basicly no voltage drop.

 Input voltage as low as 5.2v should work fine and brownout should not happen till much lower than that (when voltage drops low enough to brown out the 3.3v regulator on the FC around 4v or so)

 F4 and F7 RX ports are 5V tolerant so Hobbywing RPM sensor may be used without issue on 5V RPM pin header.

 DO NOT connect 5V and 2S busses on the pin header or you will release the magic smoke from the regulator.

 Take care that the positive pins on the throttle and RPM leads are not connected to each other internally inside the ESC (remove the + wire from RPM if this is the case)

 Though this breakout PCB is primarily meant for use with reciever packs if the RPM lead is also a second BEC lead then the reciever and RPM ports may be swapped so that RPM is connected to the 2S buss and the reciever is powered off 5V. A cover plate with reversed RCV and RPM lables is provided for this. The TPS76701QD can provide 1A make sure to not exceed this (assume 500ma for the FC, an Acher RS or similar reciever pulls about 60~80ma)

 Adam Tech 1CH-A-10 is a less expensive (and more readily available) SH1.0 crimp housing copy that can be purched from Digikey. Same goes for the whole Adam Tech "CH" line. 

 Mounting plate is to be glued together with the non copper sides facing. The two M3 holes in the middle are for locating the PCBs and clamping them together during the gluing process.

 A q-tip and alchohol can be used to clean any excess glue from the countersinks (I reccomend Devcon clear epoxy it's cheap and works well)

 The bottom with the countersinks needs to be 1.6mm thick, the top can be 1mm.

 Button head screws will be flush with the bottom and the FC can be mounted with double sided tape.
 
 2.5mm spacers between the mounting plate and the breakout PCB are required for the XT30 to be flush with the bottom (m3 nylon nuts are about 2.6mm thick). If mounting with standoffs then 6mm standoffs should be used (XT30 is 5mm + 1mm extra space between the top of the connector and the mounting surface)